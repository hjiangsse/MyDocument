#!/bin/bash

# test_menu: host address menu choose for user

PROGNAME=$(basename $0)

usage () {
    echo "$PROGNAME: usage: $PROGNAME [-l local -r remote -d direction]"
    echo "-l : local path of file or directory"
    echo "-r : romote path of file or directory"
    echo "-d : upload or download"
    return
}

working_horse () {
    while true; do
        clear
        echo "-----------------Please Select a FTP host------------ "
        echo
        touch ./tmp_addr.txt
        awk -f ./readconf.awk ./config.txt | tee ./tmp_addr.txt
        addrnum=$(wc -l ./tmp_addr.txt | cut -d" " -f 1)
        echo $addrnum
        rm ./tmp_addr.txt
        echo
        echo "----------------------------------------------------- "
        read -p  "Please select [0,1,2...or q/Q] > "

        host="Host"$REPLY

        grep -i -A 4 $host ./config.txt | tail -n+2 > ./tmp_addr.txt
        source ./tmp_addr.txt
        rm ./tmp_addr.txt

        case $REPLY in
            [[:digit:]])
                if [ "$REPLY" -gt "$addrnum" ]; then
                    echo "We do not have the host you input!"
                else
                    echo "We are working now!"
                fi
                exit
                ;;
            *)
                echo "Invalid Entry"
                exit 1
                ;;
        esac

        exit
    done
}


local=
local_set=

remote=
remote_set=

direction=
direction_set=

interactive=

while [[ -n $1 ]]; do
    case $1 in
        -h | --help)
            usage
            exit
            ;;
        -i | --interactive)
            interactive=1
            ;;
        -l)
            shift
            local=$1
            ;;
        -r)
            shift
            remote=$1
            ;;
        -d)
            shift
            direction=$1
            ;;
        *)
            usage >&2
            exit 1
            ;;
    esac
    shift
done

#interactive mode
if [[ -n $interactive ]]; then
    while true; do
        if [[ -z $local_set ]]; then
            read -p "Enter the local path(file or directory): " local
            if [ -e $local ] || [ -d $local ]; then
                echo "OK!"
            else
                echo "Invalid file or directory! Again!"
                continue
            fi
        fi

        if [[ -z $remote_set ]]; then
            read -p "Enter the remote path(file or directory): " remote
            if [ -e $remote ] || [ -d $remote ]; then
                echo "OK!"
            else
                echo "Invalid file or directory! Again!"
                continue
            fi
        fi

        if [[ -z $direction ]]; then
            read -p "Enter the direction: " direction
            case $direction in
                down | d)
                ;;
                up | u)
                ;;
                *)
                    continue
                    ;;
            esac
        fi

        if [ -n $local ] && [ -n $remote ] && [ -n $direction ]; then
            break
        fi
    done
fi


#working_horse
